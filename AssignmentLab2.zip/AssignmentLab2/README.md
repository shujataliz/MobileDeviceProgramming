# MIU_USER_STORE
Assignment to create user, login, view categories, do some calculations etc on android kotlin



<div style="display:inline"> 


 <img src="createUser.png" width="150" >
 <img src="categories.png" width="150" >
<img src="forgetPassword.png" width="150" >
 <img src="Screenshot_20230406_173220.png" width="150" >
  <img src="calculator.png" width="150" >
</div>
